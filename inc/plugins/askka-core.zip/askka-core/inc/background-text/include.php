<?php

include_once ASKKA_CORE_INC_PATH . '/background-text/helper.php';
