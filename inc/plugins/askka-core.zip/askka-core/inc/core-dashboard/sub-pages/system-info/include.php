<?php

include_once ASKKA_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-askkacore-dashboard-system-info-page.php';
