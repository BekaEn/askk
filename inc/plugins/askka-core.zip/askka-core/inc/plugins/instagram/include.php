<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/instagram/helper.php';
