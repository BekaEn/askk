<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-askkacore-instagram-list-widget.php';
