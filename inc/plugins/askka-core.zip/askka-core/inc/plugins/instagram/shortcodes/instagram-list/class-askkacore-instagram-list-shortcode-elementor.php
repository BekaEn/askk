<?php

class AskkaCore_Instagram_List_Shortcode_Elementor extends AskkaCore_Elementor_Widget_Base {

	function __construct( array $data = array(), $args = null ) {
		$this->set_shortcode_slug( 'askka_core_instagram_list' );

		parent::__construct( $data, $args );
	}
}

if ( qode_framework_is_installed( 'instagram' ) ) {
	askka_core_register_new_elementor_widget( new AskkaCore_Instagram_List_Shortcode_Elementor() );
}
