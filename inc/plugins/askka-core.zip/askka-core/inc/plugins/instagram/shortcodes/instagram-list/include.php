<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-askkacore-instagram-list-shortcode.php';
