<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/woocommerce/class-askkacore-woocommerce.php';
