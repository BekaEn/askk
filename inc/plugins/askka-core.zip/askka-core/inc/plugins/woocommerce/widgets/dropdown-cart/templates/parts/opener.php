<a itemprop="url" class="qodef-m-opener" href="<?php echo esc_url( wc_get_cart_url() ); ?>">
	<span class="qodef-m-opener-icon"><?php echo askka_core_get_svg_icon( 'cart'  ); ?></span>
	<span class="qodef-m-opener-count"><?php
		$count = '';

		$count .= '(';
		$count .= WC()->cart->cart_contents_count;;
		$count .= ')';

		echo esc_html($count);

		?></span>
</a>
