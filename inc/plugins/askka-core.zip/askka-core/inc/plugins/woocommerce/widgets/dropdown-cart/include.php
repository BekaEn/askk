<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-askkacore-woocommerce-dropdown-cart-widget.php';
