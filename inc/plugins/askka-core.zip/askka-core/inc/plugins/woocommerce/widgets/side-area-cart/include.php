<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/class-askkacore-woocommerce-side-area-cart-widget.php';
