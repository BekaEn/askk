<?php

if ( ! function_exists( 'askka_core_add_yith_wishlist_widget' && qode_framework_is_installed( 'yith-wishlist' ) ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function askka_core_add_yith_wishlist_widget( $widgets ) {
		$widgets[] = 'AskkaCoreYITHWishlistWidget';

		return $widgets;
	}

	add_filter( 'askka_core_filter_register_widgets', 'askka_core_add_yith_wishlist_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class AskkaCoreYITHWishlistWidget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_base( 'askka_core_yith_wishlist' );
			$this->set_name( esc_html__( 'Askka YITH Wishlist Link', 'askka-core' ) );
			$this->set_description( esc_html__( 'Display a link with counter to the YITH Plugin Wishlist', 'askka-core' ) );
		}

		public function render( $atts ) {

			if ( qode_framework_is_installed( 'yith-wishlist' ) ) {

				$wishlist_url   = YITH_WCWL()->get_wishlist_url();
				$wishlist_count = YITH_WCWL()->count_products();
				$holder_class   = ( 0 === $wishlist_count ) ? 'qodef--no-items' : 'qodef--has-items';
				?>
				<div class="qodef-woo-yith-wishlist-link <?php echo esc_attr( $holder_class ); ?>">
					<a class="qodef-m-link" href="<?php echo esc_url( $wishlist_url ); ?>">
						<?php echo askka_core_get_svg_icon( 'wishlist', 'qodef-wishlist-heart-svg' ); ?>
						<span class="qodef-m-link-count">(<?php echo esc_html( $wishlist_count ); ?>)</span>
					</a>
				</div>
				<?php
			}
		}
	}
}
?>
