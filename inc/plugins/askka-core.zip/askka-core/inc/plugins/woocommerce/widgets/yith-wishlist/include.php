<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/woocommerce/widgets/yith-wishlist/yith-wishlist.php';