<?php

if ( ! function_exists( 'askka_core_add_product_category_options' ) ) {
	/**
	 * Function that add global taxonomy options for current module
	 */
	function askka_core_add_product_category_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope' => array( 'product_cat' ),
				'type'  => 'taxonomy',
				'slug'  => 'product_cat',
			)
		);

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_product_category_masonry_size',
					'title'       => esc_html__( 'Image Size', 'askka-core' ),
					'description' => esc_html__( 'Choose image size for list shortcode item if masonry layout > fixed image size is selected in product category list shortcode', 'askka-core' ),
					'options'     => askka_core_get_select_type_options_pool( 'masonry_image_dimension' ),
				)
			);
			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_product_category_button_text',
					'title'       => esc_html__( 'Button Text', 'askka-core' ),
					'description' => esc_html__( 'Enter button text for list shortcode item if masonry layout > fixed image size is selected in product category list shortcode for huge square images', 'askka-core' ),
					'dependency'  => array(
						'show' => array(
							'qodef_product_category_masonry_size' => array(
								'values'        => 'askka_core_image_size_huge-square',
								'default_value' => '',
							),
						),
					),
				)
			);
			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_product_category_button_link',
					'title'       => esc_html__( 'Button Link', 'askka-core' ),
					'description' => esc_html__( 'Enter button link for list shortcode item if masonry layout > fixed image size is selected in product category list shortcode for huge square images', 'askka-core' ),
					'dependency'  => array(
						'show' => array(
							'qodef_product_category_masonry_size' => array(
								'values'        => 'askka_core_image_size_huge-square',
								'default_value' => '',
							),
						),
					),
				)
			);
			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_product_category_button_target',
					'title'       => esc_html__( 'Button Target', 'askka-core' ),
					'description' => esc_html__( 'Enter button target for list shortcode item if masonry layout > fixed image size is selected in product category list shortcode for huge square images', 'askka-core' ),
					'options'     => askka_core_get_select_type_options_pool( 'link_target' ),
					'dependency'  => array(
						'show' => array(
							'qodef_product_category_masonry_size' => array(
								'values'        => 'askka_core_image_size_huge-square',
								'default_value' => '',
							),
						),
					),
				)
			);
		}
	}

	add_action( 'askka_core_action_register_cpt_tax_fields', 'askka_core_add_product_category_options' );
}
