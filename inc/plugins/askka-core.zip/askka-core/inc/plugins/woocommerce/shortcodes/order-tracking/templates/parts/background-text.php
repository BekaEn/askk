<?php
$background_text = ! empty( $background_text ) ? esc_html( $background_text ) : esc_html__( 'burning', 'askka-core' );
?>

<span class="qodef-order-tracking-background-text"><?php echo esc_html( $background_text ); ?></span>
