<div <?php wc_product_cat_class( $item_classes ); ?>>
	<a href="<?php echo get_term_link( $category_slug, 'product_cat' ); ?>">
		<?php askka_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/image', '', $params ); ?>
		<div class="qodef-woo-product-category-list-content">
			<?php askka_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/title', '', $params ); ?>
			<?php askka_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/description', '', $params ); ?>
		</div>
	</a>
	<?php askka_core_template_part( 'plugins/woocommerce/shortcodes/product-category-list', 'templates/post-info/button', '', $params ); ?>
</div>
