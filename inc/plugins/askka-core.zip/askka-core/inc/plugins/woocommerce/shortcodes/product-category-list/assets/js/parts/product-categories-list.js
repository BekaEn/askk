(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.askka_core_product_category_list                    = {};
	qodefCore.shortcodes.askka_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.askka_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
