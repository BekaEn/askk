<?php if ( ! empty( $category_desc ) ) { ?>
	<p class="woocommerce-loop-category__description" ><?php echo esc_html( $category_desc ); ?></p>
<?php } ?>