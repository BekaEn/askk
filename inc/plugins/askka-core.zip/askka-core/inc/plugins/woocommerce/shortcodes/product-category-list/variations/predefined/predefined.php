<?php

if ( ! function_exists( 'askka_core_add_product_category_list_variation_predefined' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function askka_core_add_product_category_list_variation_predefined( $variations ) {
		$variations['predefined'] = esc_html__( 'Predefined', 'askka-core' );

		return $variations;
	}

	add_filter( 'askka_core_filter_product_category_list_layouts', 'askka_core_add_product_category_list_variation_predefined' );
}
