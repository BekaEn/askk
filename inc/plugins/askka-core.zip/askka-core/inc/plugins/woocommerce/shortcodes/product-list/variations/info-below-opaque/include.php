<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-below-opaque/info-below-opaque.php';
