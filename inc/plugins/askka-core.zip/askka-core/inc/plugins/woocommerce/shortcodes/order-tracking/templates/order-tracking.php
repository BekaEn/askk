<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php askka_core_template_part( 'plugins/woocommerce/shortcodes/order-tracking', 'templates/parts/background-text', '', $params ); ?>
	<?php askka_core_template_part( 'plugins/woocommerce/shortcodes/order-tracking', 'templates/parts/tagline', '', $params ); ?>
	<?php askka_core_template_part( 'plugins/woocommerce/shortcodes/order-tracking', 'templates/parts/title', '', $params ); ?>
	<?php echo do_shortcode( '[woocommerce_order_tracking]' ); // XSS OK ?>
</div>
