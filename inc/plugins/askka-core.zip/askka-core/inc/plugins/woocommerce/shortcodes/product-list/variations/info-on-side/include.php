<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-on-side/info-on-side.php';
