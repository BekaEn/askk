<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/class-askkacore-product-list-shortcode.php';

foreach ( glob( ASKKA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
