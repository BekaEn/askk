<?php
if ($image_dimension['size'] ==='askka_core_image_size_huge-square'):
	?>
	<div class="qodef-woo-product-category-list-button">
		<?php

		$button_text = get_term_meta( $category_id, 'qodef_product_category_button_text', true );
		$button_link = get_term_meta( $category_id, 'qodef_product_category_button_link', true );
		$button_target = get_term_meta( $category_id, 'qodef_product_category_button_target', true );

		$params = array(
			'button_layout' => 'textual',
			'target'      	=> $button_target,
			'link'      	=> $button_link,
			'text'          => $button_text,
			'size'          => 'normal',
		);

		echo AskkaCore_Button_Shortcode::call_shortcode( $params );
		?>
	</div>
<?php endif; ?>

