<?php
$title = ! empty( $title ) ? esc_html( $title ) : esc_html__( 'Track your order', 'askka-core' );
?>

<h2 class="qodef-order-tracking-title"><?php echo esc_html( $title ); ?></h2>
