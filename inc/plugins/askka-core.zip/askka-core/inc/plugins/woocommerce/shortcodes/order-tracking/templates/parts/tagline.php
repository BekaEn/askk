<?php
$tagline = ! empty( $tagline ) ? esc_html( $tagline ) : esc_html__( 'CANDLES & DIFFUSERS', 'askka-core' );
?>

<span class="qodef-order-tracking-tagline"><?php echo esc_html( $tagline ); ?></span>
