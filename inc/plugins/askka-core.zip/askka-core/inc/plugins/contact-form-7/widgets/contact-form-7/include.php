<?php

include_once ASKKA_CORE_PLUGINS_PATH . '/contact-form-7/widgets/contact-form-7/class-askkacore-contact-form-7-widget.php';
