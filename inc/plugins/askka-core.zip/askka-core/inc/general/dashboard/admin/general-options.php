<?php

if ( ! function_exists( 'askka_core_add_general_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function askka_core_add_general_options( $page ) {

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_main_color',
					'title'       => esc_html__( 'Main Color', 'askka-core' ),
					'description' => esc_html__( 'Choose the most dominant theme color', 'askka-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_page_background_color',
					'title'       => esc_html__( 'Page Background Color', 'askka-core' ),
					'description' => esc_html__( 'Set background color', 'askka-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_page_background_image',
					'title'       => esc_html__( 'Page Background Image', 'askka-core' ),
					'description' => esc_html__( 'Set background image', 'askka-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_repeat',
					'title'       => esc_html__( 'Page Background Image Repeat', 'askka-core' ),
					'description' => esc_html__( 'Set background image repeat', 'askka-core' ),
					'options'     => array(
						''          => esc_html__( 'Default', 'askka-core' ),
						'no-repeat' => esc_html__( 'No Repeat', 'askka-core' ),
						'repeat'    => esc_html__( 'Repeat', 'askka-core' ),
						'repeat-x'  => esc_html__( 'Repeat-x', 'askka-core' ),
						'repeat-y'  => esc_html__( 'Repeat-y', 'askka-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_size',
					'title'       => esc_html__( 'Page Background Image Size', 'askka-core' ),
					'description' => esc_html__( 'Set background image size', 'askka-core' ),
					'options'     => array(
						''        => esc_html__( 'Default', 'askka-core' ),
						'contain' => esc_html__( 'Contain', 'askka-core' ),
						'cover'   => esc_html__( 'Cover', 'askka-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_attachment',
					'title'       => esc_html__( 'Page Background Image Attachment', 'askka-core' ),
					'description' => esc_html__( 'Set background image attachment', 'askka-core' ),
					'options'     => array(
						''       => esc_html__( 'Default', 'askka-core' ),
						'fixed'  => esc_html__( 'Fixed', 'askka-core' ),
						'scroll' => esc_html__( 'Scroll', 'askka-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding',
					'title'       => esc_html__( 'Page Content Padding', 'askka-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'askka-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding_mobile',
					'title'       => esc_html__( 'Page Content Padding Mobile', 'askka-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content on mobile screens (1024px and below) in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'askka-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_boxed',
					'title'         => esc_html__( 'Boxed Layout', 'askka-core' ),
					'description'   => esc_html__( 'Set boxed layout', 'askka-core' ),
					'default_value' => 'no',
				)
			);

			$boxed_section = $page->add_section_element(
				array(
					'name'       => 'qodef_boxed_section',
					'title'      => esc_html__( 'Boxed Layout Section', 'askka-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_boxed' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_boxed_background_color',
					'title'       => esc_html__( 'Boxed Background Color', 'askka-core' ),
					'description' => esc_html__( 'Set boxed background color', 'askka-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_boxed_background_pattern',
					'title'       => esc_html__( 'Boxed Background Pattern', 'askka-core' ),
					'description' => esc_html__( 'Set boxed background pattern', 'askka-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_boxed_background_pattern_behavior',
					'title'       => esc_html__( 'Boxed Background Pattern Behavior', 'askka-core' ),
					'description' => esc_html__( 'Set boxed background pattern behavior', 'askka-core' ),
					'options'     => array(
						'fixed'  => esc_html__( 'Fixed', 'askka-core' ),
						'scroll' => esc_html__( 'Scroll', 'askka-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_passepartout',
					'title'         => esc_html__( 'Passepartout', 'askka-core' ),
					'description'   => esc_html__( 'Enabling this option will display a passepartout around website content', 'askka-core' ),
					'default_value' => 'no',
				)
			);

			$passepartout_section = $page->add_section_element(
				array(
					'name'       => 'qodef_passepartout_section',
					'title'      => esc_html__( 'Passepartout Section', 'askka-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_passepartout' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_passepartout_color',
					'title'       => esc_html__( 'Passepartout Color', 'askka-core' ),
					'description' => esc_html__( 'Choose background color for passepartout', 'askka-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_passepartout_image',
					'title'       => esc_html__( 'Passepartout Background Image', 'askka-core' ),
					'description' => esc_html__( 'Set background image for passepartout', 'askka-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size',
					'title'       => esc_html__( 'Passepartout Size', 'askka-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout', 'askka-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'askka-core' ),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size_responsive',
					'title'       => esc_html__( 'Passepartout Responsive Size', 'askka-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout for smaller screens (1024px and below)', 'askka-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'askka-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_content_width',
					'title'         => esc_html__( 'Initial Width of Content', 'askka-core' ),
					'description'   => esc_html__( 'Choose the initial width of content which is in grid (applies to pages set to "Default Template" and rows set to "In Grid")', 'askka-core' ),
					'options'       => askka_core_get_select_type_options_pool( 'content_width', false ),
					'default_value' => '1100',
				)
			);

			// Hook to include additional options after module options
			do_action( 'askka_core_action_after_general_options_map', $page );

			$page->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_custom_js',
					'title'       => esc_html__( 'Custom JS', 'askka-core' ),
					'description' => esc_html__( 'Enter your custom JavaScript here', 'askka-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_disable_images_lazy_loading',
					'title'         => esc_html__( 'Disable Images Lazy Loading', 'askka-core' ),
					'description'   => esc_html__( 'Note that some images that have hover animation will not load if this option is turned off', 'askka-core' ),
					'options'       => askka_core_get_select_type_options_pool( 'yes_no', false ),
					'default_value' => 'yes',
				)
			);
		}
	}

	add_action( 'askka_core_action_default_options_init', 'askka_core_add_general_options', askka_core_get_admin_options_map_position( 'general' ) );
}
