<?php

include_once ASKKA_CORE_CPT_PATH . '/class-askkacore-custom-post-types.php';
