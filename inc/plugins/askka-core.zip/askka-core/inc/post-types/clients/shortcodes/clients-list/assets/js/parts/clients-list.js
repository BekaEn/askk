(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.askka_core_clients_list             = {};
	qodefCore.shortcodes.askka_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
