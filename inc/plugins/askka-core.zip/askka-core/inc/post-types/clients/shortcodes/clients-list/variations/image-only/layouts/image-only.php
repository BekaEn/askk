<span <?php qode_framework_class_attribute( $item_classes ); ?>>
	<span class="qodef-e-inner">
		<?php askka_core_list_sc_template_part( 'post-types/clients/shortcodes/clients-list', 'post-info/image', '', $params ); ?>
	</span>
</span>
