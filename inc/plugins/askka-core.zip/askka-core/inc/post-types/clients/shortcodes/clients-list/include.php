<?php

include_once ASKKA_CORE_CPT_PATH . '/clients/shortcodes/clients-list/class-askkacore-clients-list-shortcode.php';

foreach ( glob( ASKKA_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
