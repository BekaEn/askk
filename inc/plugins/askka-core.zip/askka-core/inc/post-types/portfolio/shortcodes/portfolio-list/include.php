<?php

include_once ASKKA_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/helper.php';
include_once ASKKA_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/class-askkacore-portfolio-list-shortcode.php';

foreach ( glob( ASKKA_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
