<?php

if ( ! function_exists( 'askka_core_filter_portfolio_list_info_below_overlay' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function askka_core_filter_portfolio_list_info_below_overlay( $variations ) {
		$variations['overlay'] = esc_html__( 'Overlay', 'askka-core' );

		return $variations;
	}

	add_filter( 'askka_core_filter_portfolio_list_info_below_animation_options', 'askka_core_filter_portfolio_list_info_below_overlay' );
}
