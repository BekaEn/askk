<?php

include_once ASKKA_CORE_INC_PATH . '/icons/elegant-icons/class-askkacore-elegant-icons-pack.php';
