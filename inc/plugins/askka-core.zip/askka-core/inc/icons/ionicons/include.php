<?php

include_once ASKKA_CORE_INC_PATH . '/icons/ionicons/class-askkacore-ionicons-pack.php';
