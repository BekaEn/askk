<?php

include_once ASKKA_CORE_INC_PATH . '/icons/simple-line-icons/class-askkacore-simple-line-icons-pack.php';
