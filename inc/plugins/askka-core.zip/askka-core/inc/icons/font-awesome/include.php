<?php

include_once ASKKA_CORE_INC_PATH . '/icons/font-awesome/class-askkacore-font-awesome-pack.php';
