<?php

include_once ASKKA_CORE_INC_PATH . '/icons/linea-icons/class-askkacore-linea-icons-pack.php';
