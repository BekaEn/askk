<?php

include_once ASKKA_CORE_INC_PATH . '/icons/linear-icons/class-askkacore-linear-icons-pack.php';
