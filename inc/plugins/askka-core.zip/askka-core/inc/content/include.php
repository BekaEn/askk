<?php

include_once ASKKA_CORE_INC_PATH . '/content/helper.php';
