<?php

class AskkaCore_Blog_List_Shortcode_Elementor extends AskkaCore_Elementor_Widget_Base {

	function __construct( array $data = array(), $args = null ) {
		$this->set_shortcode_slug( 'askka_core_blog_list' );

		parent::__construct( $data, $args );
	}
}

askka_core_register_new_elementor_widget( new AskkaCore_Blog_List_Shortcode_Elementor() );
