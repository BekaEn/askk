<?php

include_once ASKKA_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/standard-compact/standard-compact.php';
