<?php

if ( ! function_exists( 'askka_core_add_blog_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function askka_core_add_blog_list_widget( $widgets ) {
		$widgets[] = 'AskkaCore_Blog_List_Widget';

		return $widgets;
	}

	add_filter( 'askka_core_filter_register_widgets', 'askka_core_add_blog_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class AskkaCore_Blog_List_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'askka-core' ),
				)
			);
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'askka_core_blog_list',
				)
			);

			if ( $widget_mapped ) {
				$this->set_base( 'askka_core_blog_list' );
				$this->set_name( esc_html__( 'Askka Blog List', 'askka-core' ) );
				$this->set_description( esc_html__( 'Display a list of blog posts', 'askka-core' ) );
			}
		}

		public function render( $atts ) {
			$atts['is_widget_element'] = 'yes';

			echo AskkaCore_Blog_List_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
