<?php

if ( ! function_exists( 'askka_core_add_blog_list_variation_standard_compact' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function askka_core_add_blog_list_variation_standard_compact( $variations ) {
		$variations['standard-compact'] = esc_html__( 'Standard Compact', 'askka-core' );

		return $variations;
	}

	add_filter( 'askka_core_filter_blog_list_layouts', 'askka_core_add_blog_list_variation_standard_compact' );
}

if ( ! function_exists( 'askka_core_load_blog_list_variation_standard_compact_assets' ) ) {
	/**
	 * Function that return is global blog asses allowed for variation layout
	 *
	 * @param bool  $is_enabled
	 * @param array $params
	 *
	 * @return bool
	 */
	function askka_core_load_blog_list_variation_standard_compact_assets( $is_enabled, $params ) {

		if ( 'standard-compact' === $params['layout'] ) {
			$is_enabled = true;
		}

		return $is_enabled;
	}

	add_filter( 'askka_core_filter_load_blog_list_assets', 'askka_core_load_blog_list_variation_standard_compact_assets', 10, 2 );
}

if ( ! function_exists( 'askka_core_set_blog_list_variation_standard_as_default_layout' ) ) {
	/**
	 * Function that set variation default layout value for this module
	 *
	 * @param string $default_value
	 * @param string $shortcode_base
	 *
	 * @return string
	 */
	function askka_core_set_blog_list_variation_standard_as_default_layout( $default_value, $shortcode_base ) {

		if ( 'askka_core_blog_list' === $shortcode_base ) {
			$default_value = 'standard-compact';
		}

		return $default_value;
	}

	add_filter( 'askka_core_filter_map_layout_options_default_value', 'askka_core_set_blog_list_variation_standard_as_default_layout', 10, 2 );
}

if ( ! function_exists( 'askka_core_register_blog_list_standard_compact_scripts' ) ) {
	/**
	 * Function that register modules 3rd party scripts
	 *
	 * @param array $scripts
	 *
	 * @return array
	 */
	function askka_core_register_blog_list_standard_compact_scripts( $scripts ) {

		$scripts['wp-mediaelement']    = array(
			'registered' => true,
		);
		$scripts['mediaelement-vimeo'] = array(
			'registered' => true,
		);

		return $scripts;
	}

	add_filter( 'askka_core_filter_blog_list_register_scripts', 'askka_core_register_blog_list_standard_compact_scripts' );
}

if ( ! function_exists( 'askka_core_register_blog_list_standard_compact_styles' ) ) {
	/**
	 * Function that register modules 3rd party scripts
	 *
	 * @param array $styles
	 *
	 * @return array
	 */
	function askka_core_register_blog_list_standard_compact_styles( $styles ) {

		$styles['wp-mediaelement'] = array(
			'registered' => true,
		);

		return $styles;
	}

	add_filter( 'askka_core_filter_blog_list_register_styles', 'askka_core_register_blog_list_standard_compact_styles' );
}
