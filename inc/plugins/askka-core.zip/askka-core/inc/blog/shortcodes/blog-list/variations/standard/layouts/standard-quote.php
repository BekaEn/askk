<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner" <?php qode_framework_inline_style( $this_shortcode->get_item_styles( $params ) ); ?>>
		<?php
		// Include post format part
		askka_core_theme_template_part( 'blog', 'templates/parts/post-format/quote' );
		?>
	</div>
</article>
