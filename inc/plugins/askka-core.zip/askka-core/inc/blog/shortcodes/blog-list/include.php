<?php

include_once ASKKA_CORE_INC_PATH . '/blog/shortcodes/blog-list/class-askkacore-blog-list-shortcode.php';

foreach ( glob( ASKKA_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
