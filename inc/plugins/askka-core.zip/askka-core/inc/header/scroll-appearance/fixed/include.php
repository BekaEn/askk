<?php

include_once ASKKA_CORE_INC_PATH . '/header/scroll-appearance/fixed/helper.php';
