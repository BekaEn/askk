<?php
// Include main navigation
askka_core_template_part( 'header/layouts/split-left-to-right', 'templates/parts/left-navigation' );

// Include logo
askka_core_get_header_logo_image();

// Include widget area one
askka_core_get_header_widget_area();
?>
