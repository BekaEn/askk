<?php

if ( ! function_exists( 'askka_core_add_split_left_to_right_header_options' ) ) {
	/**
	 * Function that add additional header layout options
	 *
	 * @param object $page
	 * @param array  $general_header_tab
	 */
	function askka_core_add_split_left_to_right_header_options( $page, $general_header_tab ) {

		$section = $general_header_tab->add_section_element(
			array(
				'name'        => 'qodef_split_left_to_right_header_section',
				'title'       => esc_html__( 'Split Left to Right Header', 'askka-core' ),
				'description' => esc_html__( 'Split left to right  header settings', 'askka-core' ),
				'dependency'  => array(
					'show' => array(
						'qodef_header_layout' => array(
							'values'        => 'split-left-to-right',
							'default_value' => '',
						),
					),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'    => 'yesno',
				'name'          => 'qodef_split_left_to_right_header_in_grid',
				'title'         => esc_html__( 'Content in Grid', 'askka-core' ),
				'description'   => esc_html__( 'Set content to be in grid', 'askka-core' ),
				'default_value' => 'no',
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_split_left_to_right_header_height',
				'title'       => esc_html__( 'Header Height', 'askka-core' ),
				'description' => esc_html__( 'Enter header height', 'askka-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'askka-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_split_left_to_right_header_side_padding',
				'title'       => esc_html__( 'Header Side Padding', 'askka-core' ),
				'description' => esc_html__( 'Enter side padding for header area', 'askka-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px or %', 'askka-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_split_left_to_right_header_background_color',
				'title'       => esc_html__( 'Header Background Color', 'askka-core' ),
				'description' => esc_html__( 'Enter header background color', 'askka-core' ),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_split_left_to_right_header_border_color',
				'title'       => esc_html__( 'Header Top Border Color', 'askka-core' ),
				'description' => esc_html__( 'Enter header border color', 'askka-core' ),
			)
		);
	}

	add_action( 'askka_core_action_after_header_options_map', 'askka_core_add_split_left_to_right_header_options', 10, 2 );
}
