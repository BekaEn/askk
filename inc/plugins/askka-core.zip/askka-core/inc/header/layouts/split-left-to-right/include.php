<?php

include_once ASKKA_CORE_INC_PATH . '/header/layouts/split-left-to-right/helper.php';
include_once ASKKA_CORE_INC_PATH . '/header/layouts/split-left-to-right/class-askkacore-split-left-to-right-header.php';
include_once ASKKA_CORE_INC_PATH . '/header/layouts/split-left-to-right/dashboard/admin/split-left-to-right-header-options.php';
include_once ASKKA_CORE_INC_PATH . '/header/layouts/split-left-to-right/dashboard/meta/split-left-to-right-header-meta.php';
