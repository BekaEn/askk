<?php if ( has_nav_menu( 'split-left-to-right-navigation' ) || has_nav_menu( 'main-navigation' ) ) : ?>
	<nav class="qodef-header-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Split Left to Right Menu', 'askka-core' ); ?>">
		<?php
		// Set main navigation menu as vertical if split-left-to-right navigation is not set
		$theme_location = has_nav_menu( 'split-left-to-right-navigation' ) ? 'split-left-to-right-navigation' : 'main-navigation';

		wp_nav_menu(
			array(
				'theme_location' => $theme_location,
				'container'      => '',
				'link_before'    => '<span class="qodef-menu-item-text">',
				'link_after'     => '</span>',
				'walker'         => new AskkaCoreRootMainMenuWalker(),
			)
		);
		?>
	</nav>
<?php endif; ?>
