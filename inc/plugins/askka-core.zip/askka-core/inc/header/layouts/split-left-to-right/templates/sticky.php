<div class="qodef-header-sticky">
	<div class="qodef-header-sticky-inner">

		<?php
		askka_core_template_part( 'header/layouts/split-left-to-right', 'templates/parts/left-navigation' );

		// Include logo
		askka_core_get_header_logo_image( array( 'sticky_logo' => true ) );


		// Include widget area one
		askka_core_get_header_widget_area( 'one', 'sticky-header-widget-area', 'sticky' );
		?>

		<?php do_action( 'askka_core_action_after_sticky_header' ); ?>
	</div>
</div>