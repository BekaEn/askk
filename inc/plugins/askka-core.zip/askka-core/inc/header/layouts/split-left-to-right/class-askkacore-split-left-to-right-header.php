<?php

class AskkaCore_Split_Left_To_Right_Header extends AskkaCore_Header {
	private static $instance;

	public function __construct() {

		$this->set_layout( 'split-left-to-right' );

		$this->set_search_layout( 'below-header' );
		$this->default_header_height = 121;

		//add_filter( 'body_class', array( $this, 'add_body_classes' ) );

		parent::__construct();
	}

	/**
	 * @return AskkaCore_Split_Left_To_Right_Header
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}
