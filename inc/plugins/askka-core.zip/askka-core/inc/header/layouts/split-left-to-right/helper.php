<?php

if ( ! function_exists( 'askka_core_add_split_left_to_right_header_global_option' ) ) {
	/**
	 * This function set header type value for global header option map
	 */
	function askka_core_add_split_left_to_right_header_global_option( $header_layout_options ) {
		$header_layout_options['split-left-to-right'] = array(
			'image' => ASKKA_CORE_HEADER_LAYOUTS_URL_PATH . '/split-left-to-right/assets/img/split-left-to-right-header.png',
			'label' => esc_html__( 'Split Left to Right', 'askka-core' ),
		);

		return $header_layout_options;
	}

	add_filter( 'askka_core_filter_header_layout_option', 'askka_core_add_split_left_to_right_header_global_option' );
}

if ( ! function_exists( 'askka_core_set_split_left_to_right_header_as_default_global_option' ) ) {
	/**
	 * This function set header type as default option value for global header option map
	 */
	function askka_core_set_split_left_to_right_header_as_default_global_option() {
		return 'split-left-to-right';
	}

	add_filter( 'askka_core_filter_header_layout_default_option_value', 'askka_core_set_split_left_to_right_header_as_default_global_option' );
}

if ( ! function_exists( 'askka_core_register_split_left_to_right_header_layout' ) ) {
	/**
	 * Function which add header layout into global list
	 *
	 * @param array $header_layouts
	 *
	 * @return array
	 */
	function askka_core_register_split_left_to_right_header_layout( $header_layouts ) {
		$header_layout = array(
			'split-left-to-right' => 'AskkaCore_Split_Left_To_Right_Header',
		);

		$header_layouts = array_merge( $header_layouts, $header_layout );

		return $header_layouts;
	}

	add_filter( 'askka_core_filter_register_header_layouts', 'askka_core_register_split_left_to_right_header_layout' );
}

if ( ! function_exists( 'askka_core_register_split_left_to_right_menu' ) ) {
	/**
	 * Function which add additional main menu navigation into global list
	 *
	 * @param array $menus
	 *
	 * @return array
	 */
	function askka_core_register_split_left_to_right_menu( $menus ) {
		$menus['split-left-to-right-navigation'] = esc_html__( 'Split Left to Right Navigation', 'askka-core' );

		return $menus;
	}

	add_filter( 'askka_filter_register_navigation_menus', 'askka_core_register_split_left_to_right_menu' );
}
