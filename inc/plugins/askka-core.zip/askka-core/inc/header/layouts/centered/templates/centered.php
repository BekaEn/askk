<?php
// Include logo
askka_core_get_header_logo_image();
?>
<div class="qodef-centered-header-wrapper">
	<?php
	// Include widget area two
	askka_core_get_header_widget_area( 'two' );

	// Include main navigation
	askka_core_template_part( 'header', 'templates/parts/navigation' );

	// Include widget area one
	askka_core_get_header_widget_area();
	?>
</div>
