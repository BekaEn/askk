<?php

include_once ASKKA_CORE_INC_PATH . '/header/layouts/centered/helper.php';
include_once ASKKA_CORE_INC_PATH . '/header/layouts/centered/class-askkacore-centered-header.php';
include_once ASKKA_CORE_INC_PATH . '/header/layouts/centered/dashboard/admin/centered-header-options.php';
include_once ASKKA_CORE_INC_PATH . '/header/layouts/centered/dashboard/meta-box/centered-header-meta-box.php';
