<?php

include_once ASKKA_CORE_INC_PATH . '/mobile-header/layouts/minimal/helper.php';
include_once ASKKA_CORE_INC_PATH . '/mobile-header/layouts/minimal/class-askkacore-minimal-mobile-header.php';
include_once ASKKA_CORE_INC_PATH . '/mobile-header/layouts/minimal/dashboard/admin/minimal-mobile-header-options.php';
