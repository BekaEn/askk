<?php

include_once ASKKA_CORE_INC_PATH . '/mobile-header/helper.php';
include_once ASKKA_CORE_INC_PATH . '/mobile-header/class-askkacore-mobile-header.php';
include_once ASKKA_CORE_INC_PATH . '/mobile-header/class-askkacore-mobile-headers.php';
include_once ASKKA_CORE_INC_PATH . '/mobile-header/template-functions.php';
