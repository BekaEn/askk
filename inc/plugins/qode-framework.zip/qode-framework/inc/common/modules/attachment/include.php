<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/attachment/core/class-qodeframeworkoptionsattachment.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/attachment/core/class-qodeframeworkpageattachment.php';
